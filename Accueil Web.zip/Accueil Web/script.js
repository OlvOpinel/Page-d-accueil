$ (document). ready (function() {
    $('#autowidth').lightslider({ 
        autoWidth: true,
        loop: true,
        onSliderLoad: function() {
        $ ('#autowidth').removeClass ('cS-hidden');

        }
    });
});